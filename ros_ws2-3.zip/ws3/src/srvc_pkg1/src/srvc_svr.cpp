#include <ros/ros.h>
#include "srvc_pkg1/Srvc1.h"

#define PLUS    1
#define MINUS   2
#define MULTI   3
#define DIV     4

int g_operator = PLUS;

// 서비스 요청이 오면 실행
bool calculation(srvc_pkg1::Srvc1::Request &req, srvc_pkg1::Srvc1::Response &res){
    
    // 파라미터 값에 따라 연산자 선택
    switch(g_operator){
        case PLUS:
            res.result = req.a + req.b; break;
        case MINUS:
            res.result = req.a - req.b; break;
        case MULTI:
            res.result = req.a * req.b; break;
        case DIV:
            if(req.b == 0){
                res.result = 0; break;
            } else {
                res.result = req.a / req.b; break;
            }
        default:
            res.result = req.a + req.b; break;
    }

    ROS_INFO("request: x=%ld, y=%ld", (long int)req.a, (long int)req.b);
    ROS_INFO("response: [%ld]", (long int)res.result);

    return true;
}

//argc(argument count): "rosrun srvc_pkg1 srvc_cli arg0 arg1"이면 4개
//argc(argument vector): argv[0], argv[1], argv[2] = srvc_cli, arg0, arg1
int main(int argc, char **argv){
    ros::init(argc, argv, "srvc_svr"); // 노드명 초기화
    ros::NodeHandle nh;   // ROS 시스템과 통신을 위한 노드 핸들 선언

    nh.setParam("cal_method", PLUS);   // 매개변수 초기값

    // 서비스 선언: Srvc1 파일을 이용해 서비스 서버를 선언함.
    // 서비스명: ros_srvc. 서비스 요청이 있을 때 calculation 실행.
    ros::ServiceServer ros_srvc_svr = nh.advertiseService("ros_srvc", calculation);

    ROS_INFO("Service server ready.");

    ros::Rate r(10);          // 10Hz

    while(1){
        nh.getParam("cal_method", g_operator); //매개변수로부터 받은 값으로 연산자 변경
        ros::spinOnce();     // 콜백함수 처리 루틴
        r.sleep();           // 루틴 반복을 위한 sleep처리
    }

    return 0;
}