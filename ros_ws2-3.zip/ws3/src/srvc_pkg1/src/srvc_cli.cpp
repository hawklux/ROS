#include <ros/ros.h>
#include "srvc_pkg1/Srvc1.h"
#include <cstdlib>  //atoll(ASCII to Long Long) 함수 사용을 위한 라이브러리

//argc(argument count): "rosrun srvc_pkg1 srvc_cli arg0 arg1"이면 4개
//argc(argument vector): argv[0], argv[1], argv[2] = srvc_cli, arg0, arg1
int main(int argc, char **argv){
    ros::init(argc, argv, "srvc_cli");  // 노드명 초기화

    // 입력값 오류 처리
    if(argc != 3){  
        ROS_INFO("cmd : rosrun srvc_pkg1 srvc_cli arg0 arg1");
        ROS_INFO("arg0: double number, arg1: double number");
        return 1;
    }

    ros::NodeHandle nh;  // ROS 시스템과 통신을 위한 노드 핸들 선언

    // 서비스 클라이언트 선언: Srvc1 서비스 파일을 이용한 서비스 클라 선언
    // 서비스명: ros_srvc
    ros::ServiceClient ros_srvc_cli = nh.serviceClient<srvc_pkg1::Srvc1>("ros_srvc");

    // srv라는 이름으로 Srvc1 서비스 파일을 이용하는 서비스를 선언
    srvc_pkg1::Srvc1 srv;

    //서비스 요청 값으로 노드가 실행될 때 입력으로 사용된 매개변수를 a, b에 저장함
    srv.request.a = atoll(argv[1]);
    srv.request.b = atoll(argv[2]);

    //서비스를 요청하고, 요청이 받아들여진 경우 응답 값을 표시함.
    if(ros_srvc_cli.call(srv)){
        ROS_INFO("send srv, srv.Request.a and b: %ld, %ld", (long int)srv.request.a, (long int)srv.request.b);
        ROS_INFO("receive srv, srv.Response.result: %ld", (long int)srv.response.result);
    }
    else{
        ROS_ERROR("Failed to call service ros_tutorial_srv");
        return 1;
    }
    return 0;

}