
"use strict";

let Srvc1 = require('./Srvc1.js')

module.exports = {
  Srvc1: Srvc1,
};
