#include "ros/ros.h"
#include "topic_pkg1/TopicMsg.h"  

int main(int argc, char **argv)
{
    ros::init(argc, argv, "topic_pub");
    ros::NodeHandle nh;  // ROS 시스템과 통신을 위한 노드 핸들 선언

    // 펴블리셔 선언. TopicMsg를 이용해 ros_msg 작성. queue 사이즈 = 100
    ros::Publisher ros_pub = nh.advertise<topic_pkg1::TopicMsg>("ros_msg", 100);

    // 루프 주기: 10Hz(0.1 sec) 간격으로 반복
    ros::Rate loop_rate(10);

    topic_pkg1::TopicMsg msg;
    
    int count = 0;

    while(ros::ok()){
        msg.stamp = ros::Time::now();
        msg.data = count;

        // print() 같은 기능
        ROS_INFO("send msg = %d", msg.stamp.sec);
        ROS_INFO("send msg = %d", msg.stamp.nsec);
        ROS_INFO("send msg = %d", msg.data);

        // 메시지 발행 실행
        ros_pub.publish(msg);

        // 위 주기 맞추기 위해 딜레이
        loop_rate.sleep();
        ++count;
    }
    return 0;

}