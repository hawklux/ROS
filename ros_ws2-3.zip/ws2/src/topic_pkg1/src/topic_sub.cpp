#include "ros/ros.h"
#include "topic_pkg1/TopicMsg.h"

// 메시지 콜백함수. msg를 수신하면 동작함. 
void msgCallback(const topic_pkg1::TopicMsg::ConstPtr& msg){
    ROS_INFO("recieve msg = %d", msg->stamp.sec);
    ROS_INFO("recieve msg = %d", msg->stamp.nsec);
    ROS_INFO("recieve msg = %d", msg->data);
}

int main(int argc, char **argv){
    // 노드명 초기화
    ros::init(argc, argv, "topic_sub");
    // ROS 시스템과 통신 위한 노드핸들 선언
    ros::NodeHandle nh;

    // Subscriber 선언. TopicMsg 파일을 이용해 ros_sub를 작성함. 
    // 토픽명은 ros_msg이고 queue 사이즈는 100.
    ros::Subscriber ros_sub = nh.subscribe("ros_msg", 100, msgCallback);

    // 대기하다가 메시지 수신되면 콜백함수 호출함.
    ros::spin();

    return 0;
}